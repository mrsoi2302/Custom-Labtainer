from docx import Document
from docx.shared import Pt
import sys

def analyze_docx(doc_path):
    try:
        document = Document(doc_path)
        paragraphs = document.paragraphs
        binary_string = ""
        index = 0
        for paragraph in paragraphs:
           if( paragraph.paragraph_format.space_before is not None):
              print(f"{index} - {paragraph.paragraph_format.space_before.pt}pt")
              index += 1

    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy file '{doc_path}'")
    # except Exception as e:
    #     print(f"Đã xảy ra lỗi: {e}")

if __name__ == "__main__":
    file_directory = sys.argv[1]
    print(file_directory)
    if file_directory.endswith(".docx") is False:
        print("Lỗi: Đường dẫn không phải là file .docx")
        sys.exit(1)
    analyze_docx(file_directory)
    
