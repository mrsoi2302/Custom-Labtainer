from docx import Document
from docx.shared import Pt
import sys
def extract_binary_from_docx(doc_path, binary_string):
    try:
        document = Document(doc_path)
        paragraphs = document.paragraphs
        if len(paragraphs) < len(binary_string):
            print("Lỗi: Độ dài chuỗi nhị phân lớn hơn số đoạn văn trong file.")
            return
        print(len(binary_string))
        for i in range(len(binary_string)):
            if binary_string[i] == "1":
                if paragraphs[i+1].style.paragraph_format.space_before is not None:
                    print(paragraphs[i+1].style.paragraph_format.space_before)
                    before_space = paragraphs[i+1].style.paragraph_format.space_before.pt
                    paragraphs[i+1].paragraph_format.space_before = Pt(before_space + 1)
                    print(paragraphs[i+1].paragraph_format.space_before)
                    print(f"Chèn bit {binary_string[i]} vào dòng số {i}")
            elif binary_string[i] == "0":
                if paragraphs[i+1].style.paragraph_format.space_before is not None:
                    before_space = paragraphs[i+1].style.paragraph_format.space_before.pt
                    paragraphs[i+1].paragraph_format.space_before = Pt(before_space - 1)
                    print(paragraphs[i+1].paragraph_format.space_before)
                    print(f"Chèn bit {binary_string[i]} vào dòng số {i}")
        document.save("hidden.docx")
        print("Đã lưu file 'hidden.docx' với các thuộc tính đã chỉnh sửa.")
        print("success")
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy file '{doc_path}'")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")
if __name__ == "__main__":
    file_directory = sys.argv[1]
    binary_path = sys.argv[2]
    if file_directory.endswith(".docx") is False:
        print("Lỗi: Đường dẫn không phải là file .docx")
        sys.exit(1)
    with open(binary_path, "r") as binary_file:
        binary_string = binary_file.read().strip()
    extract_binary_from_docx(file_directory, binary_string)
    
