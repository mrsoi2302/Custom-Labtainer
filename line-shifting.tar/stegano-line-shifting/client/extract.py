from docx import Document
from docx.shared import Pt
import sys

def extract_binary_from_docx(doc_path, base_spacing):
    try:
        document = Document(doc_path)
        paragraphs = document.paragraphs
        binary_string = ""
        for paragraph in paragraphs:
            if (paragraph.paragraph_format.space_before is None):
                continue
            if( paragraph.paragraph_format.space_before.pt > float(base_spacing)):
                binary_string += "1"
            elif ( paragraph.paragraph_format.space_before.pt < float(base_spacing)):
                binary_string += "0"
        f = open("binary_result.txt", "w")
        f.write(binary_string)
        f.close()
        print("Đã xuất chuỗi nhị phân vào file 'binary_result.txt'")
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy file '{doc_path}'")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")
if __name__ == "__main__":
    file_directory = sys.argv[1]
    base_spacing = sys.argv[2]
    if file_directory.endswith(".docx") is False:
        print("Lỗi: Đường dẫn không phải là file .docx")
        sys.exit(1)
    extract_binary_from_docx(file_directory, base_spacing)
    
